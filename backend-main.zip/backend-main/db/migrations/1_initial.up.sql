CREATE TABLE users (
  id serial PRIMARY KEY,
  username varchar(35) UNIQUE NOT NULL,
  first_name varchar(255) NOT NULL,
  last_name varchar(255) NOT NULL,
  email varchar(255) UNIQUE NOT NULL,
  "password" varchar(512) NOT NULL,
  verified boolean DEFAULT FALSE
);

CREATE TABLE files (
  id serial PRIMARY KEY,
  "name" varchar(64) NOT NULL,
  "owner_id" int not null references users(id)
);

CREATE TYPE user_role AS ENUM (
  'moderator',
  'editor',
  'reviewer',
  'viewer'
);

CREATE TABLE file_user_roles (
  id serial PRIMARY KEY,
  file_id int not null references files(id),
  user_id int not null references users(id),
  role user_role
);

CREATE TABLE file_versions (
  id serial primary key,
  file_id int not null references files(id),
  author_id int not null references users(id)
);
