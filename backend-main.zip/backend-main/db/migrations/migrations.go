// The sole purpose of this package is to embed SQL migration into our program
// and export them so that they can be imported where needed
package migrations

import (
	"embed"
	"errors"

	"github.com/golang-migrate/migrate/v4"
	_ "github.com/golang-migrate/migrate/v4/database/postgres"
	"github.com/golang-migrate/migrate/v4/source/iofs"
)

//go:embed *.sql
var Fs embed.FS

func Run(dbURL string) error {
	driver, err := iofs.New(Fs, ".")
	if err != nil {
		return err
		// zap.L().Fatal("failed to create iofs driver", zap.Error(err))
	}

	migration, err := migrate.NewWithSourceInstance("iofs",
		driver,
		dbURL)
	if err != nil {
		return err
	}

	// Attempt to run migrations
	err = migration.Up()
	if errors.Is(err, migrate.ErrNoChange) {
		// Everything is ok, nothing has changed.
		return nil
	} else if err != nil {
		return err
		// zap.L().Fatal("failed to migrate", zap.Error(err))
	}

	return nil
}
