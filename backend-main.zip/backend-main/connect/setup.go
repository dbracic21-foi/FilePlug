package connect

import (
	"context"
	"errors"
	"fmt"
	"net/http"
	"time"

	"github.com/bufbuild/connect-go"
	grpcreflect "github.com/bufbuild/connect-grpcreflect-go"
	"github.com/fileplug/backend/service/auth"
	"github.com/fileplug/backend/service/file"
	"github.com/fileplug/proto-go/auth/v1/authv1connect"
	"github.com/fileplug/proto-go/core/v1/corev1connect"
	"go.uber.org/zap"
	"golang.org/x/net/http2"
	"golang.org/x/net/http2/h2c"
)

// HTTP server configuration.
var (
	readHeaderTimeout = 2 * time.Second // Prevents slowloris attacks.
	port              = 8080
)

func Setup(authSvc auth.ServiceHandler, fileSvc file.ServiceHandler) {
	mux := http.NewServeMux()

	// gRPC reflection setup
	logInterceptor := connect.WithInterceptors(NewLoggingUnaryInterceptor())

	{
		reflector := grpcreflect.NewStaticReflector(
			authv1connect.AuthServiceName,
			corev1connect.FileServiceName,
		)

		mux.Handle((grpcreflect.NewHandlerV1(reflector))) // To support legacy clients
		mux.Handle(grpcreflect.NewHandlerV1Alpha(reflector))

	}

	// Register gRPC handlers in the http server
	mux.Handle(corev1connect.NewFileServiceHandler(fileSvc, logInterceptor))
	mux.Handle(authv1connect.NewAuthServiceHandler(authSvc, logInterceptor))

	// Initialize & start HTTP server
	srv := http.Server{
		Addr:              fmt.Sprintf(":%d", port),
		ReadHeaderTimeout: readHeaderTimeout,
		// Use h2c so we can serve HTTP/2 without TLS.
		Handler: h2c.NewHandler(mux, &http2.Server{}),
	}
	err := srv.ListenAndServe()
	if err != nil {
		zap.L().Fatal("error serving http server", zap.Error(err))
	}
}

func NewLoggingUnaryInterceptor() connect.UnaryInterceptorFunc {
	logMessageSuccess := "request handled with success"
	logMessageError := "request handled with error"
	return connect.UnaryInterceptorFunc(
		func(next connect.UnaryFunc) connect.UnaryFunc {
			return connect.UnaryFunc(func(ctx context.Context, request connect.AnyRequest) (connect.AnyResponse, error) {
				response, err := next(ctx, request)
				if err != nil {
					var connectErr *connect.Error
					if errors.As(err, &connectErr) && connectErr.Code() == connect.CodeInternal {
						zap.L().Sugar().Infow(logMessageError,
							"method", request.Spec().Procedure,
							"request", request.Any(),
							"error", connectErr,
						)
					} else {
						zap.L().Sugar().Infow(logMessageError,
							"method", request.Spec().Procedure,
							"request", request.Any(),
							"error", err,
						)
					}
				} else {
					zap.L().Sugar().Infow(logMessageSuccess,
						"method", request.Spec().Procedure,
						"request", request.Any(),
						"response", response.Any(),
					)
				}

				return response, err
			})
		},
	)
}
