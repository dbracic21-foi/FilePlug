// This file is not part of the backend, it contains scripts that are itended
// to automate common tasks in local development, such as running a linter, generating code and similar
// For example, running the command `mage Model` will invoke the function `Model()` defined in this file

//go:build mage

package main

import (
	"bytes"
	"fmt"

	embeddedpostgres "github.com/fergusstrange/embedded-postgres"
	"github.com/fileplug/backend/db/migrations"
	_ "github.com/golang-migrate/migrate/v4/database/postgres"
	"github.com/magefile/mage/sh"
)

const (
	DB_NAME     = "fileplugtmp"
	DB_USER     = "fileplug"
	DB_PASSWORD = "secret"
	DB_HOST     = "127.0.0.1"
	DB_PORT     = 5454

	// Turn this on if you need to debug postgres
	showPostgresLogs = false
)

// Generate Go files from SQL model.
func Model() error {
	// Database setup.
	databaseUri := fmt.Sprintf("postgres://%s:%s@%s:%d/%s?sslmode=disable", DB_USER, DB_PASSWORD, DB_HOST, DB_PORT, DB_NAME)
	postgresConfig := embeddedpostgres.DefaultConfig().
		Username(DB_USER).
		Password(DB_PASSWORD).
		Database(DB_NAME).
		Port(DB_PORT).
		Version(embeddedpostgres.V12)

	if !showPostgresLogs {
		// This will prevent postgres logs from showing up in stdout.
		postgresConfig = postgresConfig.Logger(&bytes.Buffer{})
	}
	postgres := embeddedpostgres.NewDatabase(postgresConfig)

	fmt.Println("[1/5] Creating a temporary Postgres database.")
	if err := postgres.Start(); err != nil {
		return err
	}
	defer postgres.Stop()

	fmt.Println("[2/5] Applying migrations to the database.")
	// Run migrations.
	if err := migrations.Run(databaseUri); err != nil {
		return err
	}

	fmt.Println("[3/5] Deleting previously generated files in db/models")
	if err := sh.Run("find", "./db/models/", "-type", "f", "!", "-name", "*.proto.go", "-delete"); err != nil {
		return err
	}

	fmt.Println("[4/5] Generating Go model from the database schema.")
	// Generate Go code from SQL model
	if err := sh.Run("sqlboiler", "psql"); err != nil {
		return err
	}
	fmt.Println("[5/5] Successfully generated sqlboiler files in db/models.")

	return nil
}

func Lint() error {
	err := sh.RunV("golangci-lint",
		"run", "./...",
		"--config", "./.github/.golangci.yml",

		// Exit with status code 0 on regular lint errors,
		// so that mage knows that linting was completed successfully
		"--issues-exit-code", "0",
	)
	return err
}

func GitInfo() error {
	commit, branch, tag, err := gitInfo()
	if err != nil {
		fmt.Printf("commit:%s, branch:%s, tag:%s", commit, branch, tag)
		return nil
	}
	return err
}

func gitInfo() (commit, branch, tag string, err error) {
	commit, err = sh.Output("git", "rev-parse", "HEAD")
	if err != nil {
		return
	}
	branch, err = sh.Output("git", "rev-parse", "--abbrev-ref", "HEAD")
	if err != nil {
		return
	}
	tag, err = sh.Output("git", "describe", "--abbrev=0", "--tags")
	if err != nil {
		err = nil // ignore error
	}
	return
}
