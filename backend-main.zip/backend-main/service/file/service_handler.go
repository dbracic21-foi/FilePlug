package file

import (
	"context"
	"fmt"
	"time"

	"github.com/bufbuild/connect-go"
	corev1 "github.com/fileplug/proto-go/core/v1"
	"github.com/fileplug/proto-go/core/v1/corev1connect"
)

const fileUploadURLDuration = 1 * time.Hour

type ServiceHandler struct {
	corev1connect.UnimplementedFileServiceHandler
	fileService FileService
}

func NewServiceHandler(fileService FileService) ServiceHandler {
	return ServiceHandler{
		fileService:                     fileService,
		UnimplementedFileServiceHandler: corev1connect.UnimplementedFileServiceHandler{},
	}
}

func (s ServiceHandler) CreateFile(
	ctx context.Context,
	req *connect.Request[corev1.CreateFileRequest],
) (*connect.Response[corev1.CreateFileResponse], error) {
	token := req.Header().Get("Authorization")
	if token == "" {
		return nil, connect.NewError(connect.CodeUnauthenticated, fmt.Errorf("authorization header not set"))
	}

	userId := 1 // TODO: extract userid from JWT
	file, err := s.fileService.CreateFile(ctx, req.Msg.FileName, userId)
	if err != nil {
		return nil, connect.NewError(connect.CodeInternal, err)
	}

	res := connect.NewResponse(&corev1.CreateFileResponse{
		Id: int32(file.ID),
	})
	return res, nil
}

func (s ServiceHandler) CreateFileVersionUploadURL(ctx context.Context, req *connect.Request[corev1.CreateFileVersionUploadURLRequest]) (*connect.Response[corev1.CreateFileVersionUploadURLResponse], error) {
	// msg := req.Msg
	// fileKey := fmt.Sprintf("file/%d/%d", msg.FileId, msg.FileVersion)
	// uploadURL, err := s.storage.CreateUploadURL(ctx, fileUploadURLDuration, fileKey)
	// if err != nil {
	// 	connect.NewError(connect.CodeInternal, err)
	// }

	// res := connect.NewResponse(&corev1.CreateFileVersionUploadURLResponse{
	// 	UploadUrl: uploadURL,
	// })
	// return res, nil
	return nil, nil
}
