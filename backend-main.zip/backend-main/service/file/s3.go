package file

import (
	"context"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

type Storage struct {
	presignClient *s3.PresignClient
}

func NewStorage(awsConfig aws.Config) Storage {
	client := s3.NewFromConfig(awsConfig)
	presignClient := s3.NewPresignClient(client)
	return Storage{
		presignClient: presignClient,
	}
}

func (s Storage) CreateUploadURL(ctx context.Context, expireIn time.Duration, fileKey string) (string, error) {
	putObjectArgs := s3.PutObjectInput{
		Bucket: aws.String("fileplug"),
		Key:    &fileKey,
	}
	res, err := s.presignClient.PresignPutObject(
		ctx,
		&putObjectArgs,
		s3.WithPresignExpires(expireIn),
	)
	if err != nil {
		return "", err
	}

	return res.URL, nil
}
