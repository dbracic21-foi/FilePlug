package file

import (
	"context"
	"database/sql"

	"github.com/fileplug/backend/db/models"
	"github.com/volatiletech/sqlboiler/v4/boil"
)

type FileService struct {
	db      *sql.DB
	storage Storage
}

func NewFileService(db *sql.DB, storage Storage) FileService {
	return FileService{
		db:      db,
		storage: storage,
	}
}

// Creates a new file
func (s FileService) CreateFile(ctx context.Context, fileName string, ownerId int) (models.File, error) {
	// TODO: Check if file with this name already exists
	file := models.File{
		Name:    fileName,
		OwnerID: ownerId,
	}

	if err := file.InsertG(ctx, boil.Infer()); err != nil {
		return models.File{}, err
	}

	return file, nil
}
