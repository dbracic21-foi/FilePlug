package auth

import (
	"errors"
	"time"

	jwt "github.com/golang-jwt/jwt/v5"
)

// Struct containing claims
type EmailTokenClaims struct {
	Sub   int
	Email string
	jwt.RegisteredClaims
}

// Temporary secret key
const secretKeyEmail string = "Secret"

// Error for invalid token
var ErrInvalidEmailJWT = errors.New("invalid Email Token")

func validateEmailJWT(tokenString string) (*jwt.Token, error) {
	token, err := jwt.ParseWithClaims(tokenString, &EmailTokenClaims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(secretKeyEmail), nil
	})
	if err != nil {
		// There was an error parsing the token = token has incorrect structure
		return nil, err
	}

	// Validate emailJWT
	if !token.Valid {
		return nil, ErrInvalidEmailJWT
	}
	return token, nil
}

func newEmailJWT(UserID int, UserEmail string) (string, error) {
	// Create claims
	claims := EmailTokenClaims{
		Sub:   UserID,
		Email: UserEmail,
		RegisteredClaims: jwt.RegisteredClaims{
			IssuedAt: jwt.NewNumericDate(time.Now()),
		},
	}

	// Create Email Token
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	// Sign Email Token
	tokenString, err := token.SignedString([]byte(secretKeyEmail))

	return tokenString, err
}

func getUserIdFromEmailJWT(tokenString string) (string, error) {
	token, err := validateEmailJWT(tokenString)
	if err != nil {
		return "", err
	}

	if claims, ok := token.Claims.(*EmailTokenClaims); ok && token.Valid {
		return claims.Email, nil
	} else {
		return "", ErrInvalidEmailJWT
	}
}
