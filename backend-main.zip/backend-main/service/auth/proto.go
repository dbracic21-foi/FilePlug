package auth

import (
	"github.com/fileplug/backend/db/models"
	authv1 "github.com/fileplug/proto-go/auth/v1"
)

func NewUserInfoProto(user *models.User) *authv1.UserInfo {
	return &authv1.UserInfo{
		FirstName: user.FirstName,
		LastName:  user.LastName,
		Email:     user.Email,
	}
}
