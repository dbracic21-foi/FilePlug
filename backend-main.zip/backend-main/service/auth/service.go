package auth

import (
	"context"
	"database/sql"
	"errors"
	"strings"

	"github.com/bufbuild/connect-go"
	"github.com/fileplug/backend/db/models"
	authv1 "github.com/fileplug/proto-go/auth/v1"
	"github.com/fileplug/proto-go/auth/v1/authv1connect"
	"github.com/volatiletech/null/v8"
	"github.com/volatiletech/sqlboiler/v4/boil"
	"go.uber.org/zap"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	validation "github.com/go-ozzo/ozzo-validation/v4"
	"github.com/go-ozzo/ozzo-validation/v4/is"
)

type ServiceHandler struct {
	authv1connect.UnimplementedAuthServiceHandler
	db *sql.DB
}

func NewServiceHandler(db *sql.DB) ServiceHandler {
	return ServiceHandler{
		db:                              db,
		UnimplementedAuthServiceHandler: authv1connect.UnimplementedAuthServiceHandler{},
	}
}

func (s ServiceHandler) SignIn(
	ctx context.Context,
	req *connect.Request[authv1.SignInRequest],
) (*connect.Response[authv1.SignInResponse], error) {
	// we always lowercase emails
	email := strings.ToLower(req.Msg.Email)
	password := req.Msg.Password
	user, err := models.Users(
		models.UserWhere.Email.EQ(email),
	).OneG(ctx)
	if err != nil {
		// TODO: check if error is SQL's NOT FOUND, if it is, only then throw this error
		return nil, connect.NewError(connect.CodeInvalidArgument, errors.New("incorrect email"))
	}
	isPasswordCorrect := CheckPasswordHash(password, user.Password)
	if !isPasswordCorrect {
		return nil, errors.New(("invalid password"))
	}

	// Create and sign JWT token
	token, err := newAccessJWT(user.ID)
	if err != nil {
		return nil, connect.NewError(connect.CodeInternal, err)
	}

	res := connect.NewResponse(&authv1.SignInResponse{
		AccessToken: token,
		UserInfo:    NewUserInfoProto(user),
	})

	return res, nil
}

func (s ServiceHandler) SignUp(ctx context.Context, req *connect.Request[authv1.SignUpRequest]) (*connect.Response[authv1.SignUpResponse], error) {
	msg := req.Msg

	// Validate request.
	if err := validation.ValidateStruct(msg,
		validation.Field(&msg.FirstName, validation.Required, validation.Length(2, 20)),
		validation.Field(&msg.LastName, validation.Required, validation.Length(2, 20)),
		validation.Field(&msg.Email, validation.Required, is.Email),
		validation.Field(&msg.Password, validation.Length(6, 64)),
	); err != nil {
		return nil, connect.NewError(connect.CodeInvalidArgument, err)
	}

	hashedPassword, err := HashPassword(msg.Password)
	if err != nil {
		return nil, err
	}

	// TODO: check if user is already signed up.
	user := models.User{
		Username:  msg.Email, // TODO: add username field to request.
		Email:     msg.Email,
		FirstName: msg.FirstName,
		LastName:  msg.LastName,
		Password:  hashedPassword,
		Verified:  null.BoolFrom(false),
	}

	if err := user.Insert(ctx, s.db, boil.Infer()); err != nil {
		return nil, connect.NewError(connect.CodeInternal, err)
	}

	// Create and sign JWT token
	accessToken, err := newAccessJWT(user.ID)
	if err != nil {
		return nil, connect.NewError(connect.CodeInternal, err)
	}

	// Generate emailJWT
	confirmEmailToken, err := newEmailJWT(user.ID, user.Email)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "error generating token: %v", err)
	}
	zap.L().Sugar().Infof("confirm email token: %s", confirmEmailToken)
	// TODO: Send account confirmation email

	res := connect.NewResponse(&authv1.SignUpResponse{
		AccessToken: accessToken,
		UserInfo:    NewUserInfoProto(&user),
	})

	return res, nil

}

func (s ServiceHandler) ConfirmEmail(ctx context.Context, req *connect.Request[authv1.ConfirmEmailRequest]) (*connect.Response[authv1.ConfirmEmailResponse], error) {
	msg := req.Msg
	// Validate request.
	if err := validation.ValidateStruct(msg,
		validation.Field(&msg.Token, validation.Required),
	); err != nil {
		return nil, connect.NewError(connect.CodeInvalidArgument, err)
	}

	email, err := getUserIdFromEmailJWT(msg.Token)

	user, err := models.Users(
		models.UserWhere.Email.EQ(email)).OneG(ctx)
	if err != nil {
		return nil, connect.NewError(connect.CodeInvalidArgument, errors.New("incorrect email"))
	}

	user.Verified = null.BoolFrom(true)
	_, err = user.Update(ctx, s.db, boil.Infer())
	if err != nil {
		return nil, connect.NewError(connect.CodeInternal, err)
	}

	// Return the access token and user info in the response
	res := connect.NewResponse(&authv1.ConfirmEmailResponse{
		AccessToken: email,
		UserInfo:    NewUserInfoProto(user),
	})
	return res, nil
}
