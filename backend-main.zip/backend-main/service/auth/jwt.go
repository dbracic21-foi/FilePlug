package auth

import (
	"errors"
	"strconv"
	"time"

	jwt "github.com/golang-jwt/jwt/v5"
)

// Struct containing claims
type AccessTokenClaims struct {
	jwt.RegisteredClaims
}

// Temporary secret key
const secretKey string = "Secret"

// Error for invalid token
var ErrInvalidJWT = errors.New("invalid token")

// Checks AccessJWT validity and returns Subject field
func ParseAccessJWT(tokenString string) (int, error) {
	token, err := jwt.ParseWithClaims(tokenString, &AccessTokenClaims{}, func(token *jwt.Token) (interface{}, error) {
		return []byte(secretKey), nil
	})
	if err != nil {
		// There was an error parsing the token = token has incorrect structure
		return 0, err
	}

	// Check token validity and return sub field
	if claims, ok := token.Claims.(*AccessTokenClaims); ok && token.Valid {
		sub, err := strconv.ParseInt(claims.RegisteredClaims.Subject, 10, 64)
		if err != nil {
			return 0, err
		}
		return int(sub), nil
	} else {
		return 0, ErrInvalidJWT
	}
}

func newAccessJWT(userID int) (string, error) {
	// Create claims
	claims := AccessTokenClaims{
		RegisteredClaims: jwt.RegisteredClaims{
			Subject:   strconv.Itoa(userID),
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(24 * time.Hour)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	// Create JWT
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	// Sign JWT
	tokenString, err := token.SignedString([]byte(secretKey))

	return tokenString, err
}
