package main

import (
	"context"
	"database/sql"

	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/fileplug/backend/connect"
	"github.com/fileplug/backend/db/migrations"
	"github.com/fileplug/backend/service/auth"
	"github.com/fileplug/backend/service/file"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/volatiletech/sqlboiler/v4/boil"
	"go.uber.org/zap"
)

// This variable is set in build step via linker flags.
var Commit string

func main() {
	// Logger setup. This must run before everything else
	log, err := zap.NewDevelopment()
	if err != nil {
		zap.L().Fatal("failed to initialize logger", zap.Error(err))
	}

	zap.ReplaceGlobals(log)
	defer func() {
		if err := log.Sync(); err != nil {
			zap.L().Fatal("failed to sync logger", zap.Error(err))
		}
	}()

	log.Info("Startup", zap.String("commit", Commit))

	// S3 storage setup
	awsConfig, err := config.LoadDefaultConfig(
		context.Background(),
		config.WithCredentialsProvider(
			credentials.NewStaticCredentialsProvider(
				"ACCESS_KEY_ID",
				"SECRET_ACCESS_KEY",
				"",
			),
		),
	)
	if err != nil {
		zap.L().Fatal("faled to load aws/s3 config")
	}
	storageService := file.NewStorage(awsConfig)

	// Apply migrations.
	dbURL := "postgres://fileplug:secret@localhost:5432/fileplug?sslmode=disable"
	if err := migrations.Run(dbURL); err != nil {
		zap.L().Fatal("couldn't apply migrations", zap.Error(err))
	}

	// Connect to the database.
	db, err := sql.Open("pgx", dbURL)
	if err != nil {
		zap.L().Fatal("couldn't connect to database", zap.Error(err))
	}
	boil.SetDB(db)

	fileService := file.NewFileService(db, storageService)

	authServiceHandler := auth.NewServiceHandler(db)
	fileServiceHandler := file.NewServiceHandler(fileService)
	connect.Setup(authServiceHandler, fileServiceHandler)
}
